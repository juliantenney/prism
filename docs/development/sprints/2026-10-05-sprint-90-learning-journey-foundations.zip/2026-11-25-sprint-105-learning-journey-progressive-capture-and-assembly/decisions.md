# Sprint 105 — Decisions

## S105-D01 — Open Sprint 105 — Learning Journey Progressive Capture and Assembly

**Date:** 2026-11-25  
**Status:** **Accepted**  
**Baseline:** `f1f1269` (Sprint 104 M1–M5 complete & committed; Sprint 104 suspended at live acceptance via `S104-D04`)

**Decision:**

1. Open **Sprint 105 — Learning Journey Progressive Capture and Assembly** as the active priority sprint ahead of Connect More (Wed 2 Dec 12:00).
2. Retain the existing 5-stage Learning Journey educational design process (`Requirements` → `Progression` → `Elements` → `Commissioning` → `Design Page`) and move from monolithic Step 5 JSON capture to **progressive structured capture, validation, persistence, and deterministic final assembly**, reusing established PRISM Interactive/Expository partial-page mechanisms wherever appropriate.
3. Keep **Phase 105A strictly documentation-only**: inspect existing progressive capture/assembly mechanisms, map exact stage-by-stage field ownership, audit confirmed defects and lifecycle rules, assess recovery of the incomplete Economics run, and stop for review before any implementation, broad regression runs, or live generation.
4. Preserve both the original pre-intervention Economics baseline and the current incomplete Economics regeneration untouched.

---

## S105-D02 — Stage Authority, Progressive Capture, and Deterministic Assembly Contract

**Date:** 2026-11-25  
**Status:** **Accepted** (Phase 105A approved with refinements 1–9 below; Milestone 1 implemented and stopped for review)

### 1. Binding architectural refinements

1. **Immutable final Design Page contract:** The existing Learning Journey Design Page schema (`lib/learning-journey-design-page.js`) is immutable for Sprint 105. Intermediate capture schemas derive from it, not the other way round. **Zero intermediate-only fields** may leak into the assembled final Design Page. Downstream consumers (`lib/first-class-commission-intake.js`, `lib/learning-journey-unified-shell.js`, `lib/learning-journey-learner-package.js`, `lib/learning-journey-shared-source.js`, `lib/learning-journey-workload-feasibility-adapter.js`) remain unchanged.
2. **Minimum sufficient structured information:** Each stage outputs all and only the information required by its educational purpose, subsequent stages, and deterministic final assembly (no mechanical prose-heading-to-JSON translation). Every intermediate field has an explicit purpose and consumer (table below).
3. **Distinguish reasoning from capture:** Models undertake full educational reasoning while capturing only consequential decisions, constraints, and rationale needed subsequently. Stage ownership is enforced structurally in M1 and semantic economy via prompt guidance in M2, without arbitrary word limits.
4. **Single-stage authority & deterministic transport:** Each stage owns its authoritative information. Later stages must never regenerate earlier authoritative fields or anticipate later decisions. Established authoritative data is transported deterministically by the assembler wherever possible — including **Stage 1 `learning_outcomes`** (deterministically injected into `commissions[].journey_context_text`) and **brief-provided authoritative source material** (Stage 4 declares `{ status: "provided" }` without copying the corpus; assembler transports `briefProvidedSourceContext` verbatim into `shared_authoritative_material`).
5. **Complete progressive assembly:** **All five** accepted, valid, current stage captures (`learning_requirements`, `learning_progression`, `learning_elements`, `learning_commissions`, `design_page`) are **mandatory**. Stages 2 and 3 are authoritative educational design stages, not optional diagnostic inputs.
6. **Strict legacy separation:** Legacy monolithic workflows remain supported, **but monolithic Step 5 capture must never provide a validation bypass for explicitly progressive workflows** (`progressive_capture_version: "s105_v1"` / `outputSpec.partialPageOutputs: true`).
7. **Stored captures are authoritative (binding for M2/M3):** Accepted structured captures take precedence over conversational context, particularly following author edits. M2/M3 prompt handoff and invalidation must honour stored captures without unnecessary input duplication or reliance on superseded conversational state.
8. **Preserve existing educational & operational contracts:** Retain all Sprint 104 safeguards, authoritative durations (`duration_contract_version: "s104_m1"`), outcomes, commission specifications, continuity, shared source fidelity, and Journal semantics.
9. **Preserve Economics evidence:** Original baseline and incomplete regeneration remain untouched; no recovery or migration mechanism is built; live validation runs on a fresh workflow.

### 2. Minimal sufficient stage schemas — field purpose & consumer map

Shared stage envelope (Stages 1–4): `artifact_type: "learning_journey_stage"`, `schema_version: "1.0.0"`, `stage` (unambiguous discriminator preventing cross-stage mix-ups). All stages enforce strict allowed-key validation (unknown/upstream/downstream keys rejected).

| Stage | Owned Fields | Purpose & Downstream Consumer | Stripped from Final DP? |
| ----- | ------------ | ----------------------------- | ----------------------- |
| **1. `learning_requirements`** (`step_journey_requirements`) | `journey_allocated_minutes`, `learning_outcomes` (DLO), `learner_profile`, `purpose`, `body_of_knowledge`, optional `constraints_and_tradeoffs`, optional `journal_orientation` | Establishes authoritative time envelope (Stages 2–4 & final `learning_journey.allocated_minutes`), authoritative journey outcomes (Stages 2–4 + deterministic injection into final `commissions[].journey_context_text`), learner starting point & scope (Stages 2–5), feasibility constraints (S104 M4), and optional Journal signal (Stages 2 & 4). | Stage 1 artefact stays upstream; only `journey_allocated_minutes` and `learning_outcomes` transport into final DP. |
| **2. `learning_progression`** (`step_journey_progression`) | `journey_structure` (`mode: "single"\|"constituent"`, `rationale`, optional `constituent_journeys[]`), `developmental_phases[]` (`phase_id`, `title`, optional `constituent_id`, `purpose`, `indicative_minutes`, `scaffolding_and_evidence`, optional `dependencies`), `developmental_arc`, optional `journal_note` | Establishes single vs constituent architecture, ordered developmental phases with minute reconciliation against Stage 1, scaffolding/evidence trajectory, and `phase_id` anchors consumed by Stage 3 (plus `developmental_arc` for Stage 5 framing). | Stays upstream (authoritative design stage; validated before assembly). |
| **3. `learning_elements`** (`step_journey_elements`) | `elements[]` (`element_id`, `phase_id`, `title`, `educational_job`, `knowledge_focus`, `indicative_minutes`, optional `scaffolding_and_feedback`, optional `dependencies`, optional `journal_producer_candidate`), optional `boundary_notes` | Establishes learner-manageable educational jobs anchored to Stage 2 `phase_id`s (with per-phase and total minute reconciliation) and `element_id` coverage anchors consumed by Stage 4. | Stays upstream (authoritative design stage; 100% element coverage enforced against Stage 4). |
| **4. `learning_commissions`** (`step_journey_commissioning`) | `shared_authoritative_material` (`{ status, content? }`), `commissions[]` (`commission_id`, `section_id`, `order`, `title`, `product_id`, `status`, `allocated_minutes`, `specification_text` [with `<<<COMPONENT_LEARNING_OUTCOMES_BEGIN>>>`], `journey_context_text`, optional `dependencies`, `element_ids[]`, optional `relevant_journey_outcome_numbers[]`), `continuity`, `journal` (`enabled`, optional `decision_basis`, optional `title`, `entries[]`: `{ entry_id, order, title, artefact_id, framing? }`), optional `feasibility_note` | Authoritative owner of shared corpus (or `"provided"` reference for brief-supplied source), canonical final-DP `commissions[]` + durations, continuity summary, and structural Journal inclusion/producer bindings. `element_ids` enforces Stage 3 coverage; `relevant_journey_outcome_numbers` selects Stage 1 outcome subset; `decision_basis` & `feasibility_note` guide Stage 5. | `element_ids`, `relevant_journey_outcome_numbers`, `decision_basis`, and `feasibility_note` are **strictly stripped** before final DP emission. |
| **5. `design_page`** (`step_design_page` / `learning_journey_page` thin partial) | `artifact_type: "page"`, `schema_version: "2.0.0"`, `product_id: "learning_journey"`, `title`, `editorial_opening_image`, `sections[]` (`journey_intro` + 1:1 ordered Stage 4 `section_id`s + optional single closing section), `learning_journey: { design_intent, journal?: { title?, entries?: [{ entry_id, framing }] } }`, `assembly_state` | Owns genuinely new learner-facing synthesis only: journey title, decorative opening image decision, learner-facing section framing constrained 1:1 to Stage 4 commissions, overall `design_intent`, and optional learner-facing Journal `title`/`framing` keyed strictly to Stage 4 `entry_id`. | All owned fields assemble cleanly into final DP; forbids `commissions`, `shared_authoritative_material`, `activities`, `allocated_minutes`, `continuity`, `journal.enabled`, `artefact_id`, and Interactive fields. |

---

## S105-D03 — Optional Block-Level Material Anchors in Expository Exposition

**Date:** 2026-11-25  
**Status:** **Accepted, Implemented & Live-Accepted (Economics C1: 91/100)**

**Context:**  
In Expository resources, `sections[].exposition` is a continuous Markdown string and `sections[].materials[]` previously rendered solely at the end of non-terminal sections (or before closing prose on terminal sections). Supporting coherent pedagogical sequences (*framing → evidence → explanation → interpretation → synthesis*) across disciplines requires positioning supporting materials at authored points inside continuous exposition without breaking the shared `sections[].exposition` contract, introducing Interactive reveal mechanics, or coupling Expository to Practice semantics.

**Decision:**
1. **Schema & ownership preservation:** Retain the existing Design Page schema (`schema_version: "2.0.0"`) and `sections[].exposition` Markdown string. **XD** owns narrative sequencing, `materials_commission[]`, and optional anchor placement; **XM** realises commissions 1:1 without altering `exposition` or placement; Design Page ownership boundaries remain unchanged.
2. **Shared deterministic anchor contract (`lib/expository-material-anchors.js`):**
   - Syntax: standalone block-level line `[[material:<commission_id>]]` outside fenced code blocks (` ``` ` / `~~~`).
   - Anchors are **never** recognised inside code fences, inline code, blockquotes, or ordinary quoted prose.
   - Anchors bind **exclusively** to authoritative `commission_id` values within the same section — **no secondary `material_id` fallback**.
3. **Fail-fast capture & assembly validation:** Unknown, malformed, cross-section, duplicate, or `material_id`-addressed anchors produce explicit validation errors at XD capture (`lib/expository-contracts.js`) and Expository assembly (`lib/page-vnext-assemble.js`).
4. **Defensive rendering & diagnostics (`lib/learner-renderer-vnext/render-page.js`):** For imported, legacy, or malformed artefacts, unresolved/malformed/duplicate directives are stripped cleanly (zero raw syntax leakage into learner prose), materials are never duplicated or silently dropped (unanchored materials append deterministically), and actionable diagnostics are surfaced in `anchorDiagnostics` and `modelResult.warnings`.
5. **Fulfilled visual affordances:** Section-scoped visual affordances explicitly linked to an anchored XM material (`commission_id`, `material_id`, exact `<sectionId>.materials.<id>` in `evidence_anchors[]` or `source_basis`) render inline at that material's anchor slot with caption and accessible equivalents when fulfilled, with strict deduplication and zero fuzzy/proximity matching. Unfulfilled linked illustrations preserve their accessible fallback inline; unlinked section-level figures retain existing section-end placement.
6. **EQ8, backwards compatibility & publication parity:** Unanchored artefacts (including the preserved Economics C1 artefact) follow the exact existing rendering path unchanged. Anchored terminal sections preserve the final prose segment as the EQ8 consolidating close (unanchored materials and unlinked section figures precede it). Implementing inline anchor resolution in `render-page.js` and rebuilding `lib/learner-renderer-vnext-browser.js` guarantees parity across preview, standalone ZIP export, and unified Learning Journey publication.

---

## S105-D04 — Close Sprint 105 — Complete and Hand Back to Sprint 104

**Date:** 2026-11-25  
**Status:** **Accepted**  
**Implementation baseline:** `4b698db` (M1), `09cfbfc` (M2), `83e7aec` (M3), `a7ad249` (M4 live-acceptance fixes, Workstream 1, `S105-D03`, and Economics C1 acceptance)

**Decision:**

1. **Close Sprint 105 as `CLOSED — COMPLETE`** following full automated regression verification, live 5-stage generation of both the fresh 90-minute Economics Learning Journey and a 30-hour / 10-week / 50-component Political Economy Learning Journey (scalability evidence for progressive capture and assembly only — no claim of full Political Economy component production or runtime validation), live acceptance of regenerated Economics C1 at **91 / 100 (Professional / Excellent)**, and user confirmation of all six outstanding manual browser acceptance checks (reload persistence, parent Overview preview, legacy compatibility & historical baseline preservation, workflow duplication, upstream invalidation & authoritative prompt propagation without reload resurrection, and clear-run behaviour).
2. **Distinguish evidence classes transparently:** Record that verbatim transport and preservation of brief-provided source material (`{ status: "provided" }`) across duplication, invalidation, and clear-run is verified by automated regression suites (`s105-m1`, `s105-m2`, `s105-m3`, `s96-lj-shared-source-design-page-boundary`) rather than a separately recorded live brief-provided run.
3. **Preserve all deferred items and non-blocking observations:** Retain `S105-AD-005` (minor Markdown blockquote `&gt;` defect), `D-016` (deferred native deterministic `number_line_segments` SVG rendering), and the non-blocking C1 workload observation (~12–15 min estimated workload vs 10 min commissioned; actual learner completion times unmeasured) without reopening Sprint 105 or regenerating C1.
4. **Formally hand back to Sprint 104 (`S104-D05`):** Resume Sprint 104 at its outstanding live acceptance milestones (`M1` integrated live acceptance, `M6` 5-/15-/30-min Practice sensitivity probes, and `M7` remaining Economics component generation, workload assessment, baseline comparison, QA, and unified learner-runtime acceptance), adopting the fresh 90-minute Economics Learning Journey as canonical parent workflow while preserving both historical Economics baselines untouched.

