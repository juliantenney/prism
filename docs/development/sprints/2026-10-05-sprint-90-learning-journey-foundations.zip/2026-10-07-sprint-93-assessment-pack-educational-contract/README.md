# Sprint 93 — Index

**Sprint:** 93 — Assessment Pack Educational Contract  
**Status:** **CLOSED — ACCEPTED** (2026-10-12)  
**Entry:** [SPRINT-93-START-HERE.md](SPRINT-93-START-HERE.md)  
**Charter:** [SPRINT-93-CHARTER.md](SPRINT-93-CHARTER.md)  
**Design map:** [PRODUCT-DESIGN-MAP.md](PRODUCT-DESIGN-MAP.md)  
**Gate 1:** [GATE-1-ASSESSMENT-PACK-BASELINE.md](GATE-1-ASSESSMENT-PACK-BASELINE.md)  
**Gate 2:** [GATE-2-LONG-JOURNEY-EVIDENCE.md](GATE-2-LONG-JOURNEY-EVIDENCE.md) · [GATE-2-EVIDENCE-LEDGER.md](GATE-2-EVIDENCE-LEDGER.md)  
**Closure:** [SPRINT-93-CLOSURE.md](SPRINT-93-CLOSURE.md) — **CLOSED — ACCEPTED**

| Document | Role |
| -------- | ---- |
| [SPRINT-93-START-HERE.md](SPRINT-93-START-HERE.md) | Session entry, NON-SUMMATIVE invariant, active gate |
| [SPRINT-93-CHARTER.md](SPRINT-93-CHARTER.md) | Mission, method, non-decisions |
| [PRODUCT-DESIGN-MAP.md](PRODUCT-DESIGN-MAP.md) | Discovery gates 1–10 |
| [GATE-1-ASSESSMENT-PACK-BASELINE.md](GATE-1-ASSESSMENT-PACK-BASELINE.md) | Current product inventory |
| [GATE-2-LONG-JOURNEY-EVIDENCE.md](GATE-2-LONG-JOURNEY-EVIDENCE.md) | Long-journey evidence (PASSED) |
| [GATE-2-EVIDENCE-LEDGER.md](GATE-2-EVIDENCE-LEDGER.md) | Live capture ledger |
| [GATE-3-ASSESSMENT-PACK-EDUCATIONAL-ROLES.md](GATE-3-ASSESSMENT-PACK-EDUCATIONAL-ROLES.md) | Educational roles R1/R2 (PASSED) |
| [GATE-4-ASSESSMENT-PACK-PRODUCT-BOUNDARY.md](GATE-4-ASSESSMENT-PACK-PRODUCT-BOUNDARY.md) | Product boundary (PASSED) |
| [GATE-5-ASSESSMENT-PACK-LEARNER-CONTRACT.md](GATE-5-ASSESSMENT-PACK-LEARNER-CONTRACT.md) | Learner contract (PASSED) |
| [GATE-6-ASSESSMENT-PACK-AUTHORING-RESPONSIBILITIES.md](GATE-6-ASSESSMENT-PACK-AUTHORING-RESPONSIBILITIES.md) | Authoring responsibilities AR1–AR5 (PASSED) |
| [GATE-7-ASSESSMENT-PACK-PRODUCT-INVARIANTS.md](GATE-7-ASSESSMENT-PACK-PRODUCT-INVARIANTS.md) | Product invariants AP-I1…I6 (PASSED) |
| [GATE-8-ASSESSMENT-PACK-PREDETERMINED-PIPELINE.md](GATE-8-ASSESSMENT-PACK-PREDETERMINED-PIPELINE.md) | Predetermined pipeline (PASSED) |
| [GATE-9-ASSESSMENT-PACK-CANONICAL-STRUCTURED-ARTEFACT.md](GATE-9-ASSESSMENT-PACK-CANONICAL-STRUCTURED-ARTEFACT.md) | Canonical artefact `assessment_evidence` (PASSED) |
| [ASSESSMENT-PACK-OUTPUT-TO-SPEC-CONTRACT.md](ASSESSMENT-PACK-OUTPUT-TO-SPEC-CONTRACT.md) | Optional `output_specification` (implemented; accepted at close) |
| [PLAN.md](PLAN.md) | Work log |
| [VALIDATION.md](VALIDATION.md) | Evidence ledger |
| [ARCHITECTURAL-DEBT.md](ARCHITECTURAL-DEBT.md) | Debt / deferred findings |
| [decisions.md](decisions.md) | S93-D01…D12 |
| [STATUS.md](STATUS.md) | Dashboard |
| [HANDOVER.md](HANDOVER.md) | Continuity |
| [next-chat-briefing.md](next-chat-briefing.md) | Compact load |
| [SPRINT-93-CLOSURE.md](SPRINT-93-CLOSURE.md) | Closure record |

**Predecessor (CLOSED):** [Sprint 92 — Situated Task](../2026-10-07-sprint-92-situated-learning-activity-first-class-product/SPRINT-92-CLOSURE.md) — **do not reopen**  
**Backlog:** [PB-FA-017](../../../backlog/PRODUCT-BACKLOG.md#pb-fa-017--assessment-pack-first-class-product-revisit)

Programme pointer: [NEXT-SPRINT.md](../../../sprints/NEXT-SPRINT.md)
